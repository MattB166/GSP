Axes
by Pavel Kutejnikov

License: CC0 (public domain)

If you want to support me, you can add to your wishlist my rogue-like game "Tzakol in Exile":
https://store.steampowered.com/app/1764840/Tzakol_in_Exile/

You can also purchase these two small games:
https://vkplay.com/play/game/boulder/
https://vkplay.com/play/game/caterpillarnoid/

Good luck!